// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;
extern"C"void longest_inc(int *,int);

int main()
{
	int size;
	int inc_size=0;
	int indexstart=0;
	cout<<"Input size of array"<<endl;
	cin>>size;
	//int *arr= new int [size];
	int *arr= new int [size];
	for(int i=0;i<size;i++)
	{
		cout<<"Input at index "<<i<<endl;
		cin>>arr[i];
	}
	longest_inc(arr,size);
	__asm
	{
		mov	inc_size,eax
		mov indexstart,ebx
	}
	cout<<"The size is "<<inc_size<<endl;
	cout<<"The starting index  is "<<indexstart<<endl;
	for(int i=indexstart;i<inc_size+indexstart;i++)
	{
		cout<<arr[i]<<endl;
	}
	//for(
	return 0;
}

