#include <iostream>
#include <fstream>
using namespace std;

void freq(char *data,int count,int orcount,char*filedata)
{
	int **arr = new  int*[count];int row;int col;int index=0;int innerindex=0;
	int tempecx=0;
	for(int i=0;i<count;i++)
	{
		arr[i]=new int [count];
	}
	for(int i=0;i<count;i++)
	{
		for(int j=0;j<count;j++)
		{
			arr[i][j]=0;
		}
	}
	orcount--;
	__asm
	{
		mov ecx,orcount;
		l1:
			mov esi,filedata
			add esi,index
			mov al,[esi]
			cmp al,' '
			JE gotolast
			mov tempecx,ecx
			mov ecx,count
			l2:
				mov esi,data
				add esi,innerindex
				cmp al,[esi]
				JNE donothing
					mov eax,innerindex
					mov row,eax
					mov ecx,1 // terminaling condition
				donothing:
				inc innerindex
			loop l2
			mov innerindex,0
			mov esi,filedata
			add esi,index
			inc esi
			mov eax,[esi]
			cmp al,' '
			JE gotolast
			mov ecx,count
			l3:
				mov esi,data
				add esi,innerindex
				cmp al,[esi]
				JNE donothing3
					mov eax,innerindex
					mov col,eax
					mov ecx,1
				donothing3:
				inc innerindex
			loop l3
			mov innerindex,0
			mov esi,arr
			mov eax,row
			mov ebx,4
			mul ebx
			add esi,eax
			mov eax,col
			mov ebx,4
			mul ebx
			mov ebx,[esi]
			add ebx,eax
			inc [ebx]
			gotolast:
			mov ecx,tempecx
			inc index
		dec ecx
		cmp ecx,0
		JNE l1
	}
	ofstream output;
	output.open("output.txt");char *temp=new char;bool firstitem=true;
	int increase=0;
	output.write("              ",5);
	for(int k=0;k<count;k++)
	{
		temp=data;
		output.write(temp,1);
		data++;
		increase++;
		output.write("              ",5);
	}
	output<<"\n";
	data=data-increase;
	for(int i=0;i<count;i++)
	{
		for(int j=0;j<count+1;j++)
		{
				if(firstitem)
				{
					temp=data;
					output.write(temp,1);
					data++;
					output.write("              ",4);
					firstitem=false;
				}
				else
				{
					output<<arr[i][j-1];
					output.write("              ",5);
				}
		}
		firstitem=true;
		output<<"\n";
		//cout<<endl;
	}
}

bool found(char temp,char *data,int count)
{
	char temp2=temp;
	if(temp >=97 && temp <=122)
	{
		temp2=-32;
	}
	else
	{
		temp2=+32;
	}
	for(int i=0;i<count;i++)
	{
		if(temp == data[i] || temp2==data[i])
		{
			return false;
		}
	}
	return true;
}
void lowerit(char * data,char * filedata , int count ,int count2)
{
	for(int i=0;i<count;i++)
	{
		if(data[i] >=65  && data[i] <= 90)
			data[i]=data[i]+32;
	}
	for(int i=0;i<count2;i++)
	{
		if(filedata[i] >=65 && filedata[i] <=90)
			filedata[i]=filedata[i]+32;
	}
}
int main()
{
	int numofcharacters=0;char *data=NULL;char * filedata=NULL;char temp;
	ifstream input;int index=0;int index1=0;
	input.open("input.txt"); // the file to take data from
	while(true) // this loop checks the number of character in the file
	{
		if(input.peek() == -1)
			break;
		temp=input.get();
		if((temp != '\n') && ((temp >= 97 && temp <= 122) || (temp >=65 && temp <=90) || temp == ' ' ))
			numofcharacters++;
	}
	data = new char [numofcharacters]; // this allocates the space to data equal to num of character in input file
	filedata = new char [numofcharacters];
	input.close(); // file is closed
	input.open("input.txt"); // file is opened again so that file pointer is on the top of file
	while(true)
	{
		if(input.peek() == -1)
			break;
		temp=input.get();
		if((temp != '\n') && ((temp >= 97 && temp <= 122) || (temp >=65 && temp <=90) || temp == ' ') )
		{
			if(found(temp,data,index) && temp !=' ')
			{
				data[index]=temp;
				index++;
			}
			filedata[index1]=temp;
			index1++;
		}	
	}
	input.close();
	lowerit(data,filedata,index,index1);
	freq(data,index,index1,filedata);
	system("Pause");
	return 0;
}