#include <iostream>
#include <fstream>
using namespace std;

void encrypt1(char *data, int count)
{
	__asm
	{
		mov esi,data;
		mov al,11111111b
		mov ecx,count
		l1:
			ror [esi],4
			inc esi
		loop l1
	}

}

void encrypt2(char *data, int count)
{
	__asm
	{
		mov esi,data;
		mov al,11111111b
		mov ecx,count
		l1:
			xor [esi],al
			inc esi
		loop l1
	}

}

void encrypt3(char *data, int count)
{
	__asm
	{
		mov esi,data;
		mov al,11111111b
		mov ecx,count
		l1:
			rol [esi],2
			inc esi
		loop l1
	}

}

void decrypt1(char *data, int count)
{
	__asm
	{
		mov esi,data;
		mov al,11111111b
		mov ecx,count
		l1:
			ror [esi],2
			inc esi
		loop l1
	}

}

void decrypt2(char *data, int count)
{
	__asm
	{
		mov esi,data;
		mov al,11111111b
		mov ecx,count
		l1:
			xor [esi],al
			inc esi
		loop l1
	}

}

void decrypt3(char *data, int count)
{
	__asm
	{
		mov esi,data;
		mov al,11111111b
		mov ecx,count
		l1:
			rol [esi],4
			inc esi
		loop l1
	}

}
int main()
{
	int numofcharacters=0;char *data=NULL;char temp;
	ifstream input;ofstream output;
	input.open("plainfile.txt"); // the file to take data from
	output.open("encrypted1.txt"); // the file to insert data in
	while(true) // this loop checks the number of character in the file
	{
		if(input.peek() == -1)
			break;
		temp=input.get();
		if(temp != '\n')
			numofcharacters++;
	}
	data = new char [numofcharacters]; // this allocates the space to data equal to num of character in input file
	input.close(); // file is closed
	input.open("plainfile.txt"); // file is opened again so that file pointer is on the top of file
	int i=0;
	cout<<"The Plain data read from file is"<<endl;
	while(!input.eof()) // inserting data from plainfile.txt in the array data
	{
		data[i]=input.get();
		cout<<data[i];
		i++;
	}
	cout<<endl;i--;
	cout<<"Step 1 encrypted and placed in encrypted1.txt"<<endl;
	encrypt1(data,i); 
	output.write(data,i); 
	output.close();
	cout<<"Step 1 encrypted and placed in encrypted2.txt"<<endl;
	output.open("encrypted2.txt");
	encrypt2(data,i); 
	output.write(data,i); 
	output.close();
	cout<<"Step 1 encrypted and placed in encrypted3.txt"<<endl;
	output.open("encrypted3.txt");
	encrypt3(data,i); 
	output.write(data,i); 
	output.close();
	// the encrypted data is written onto the encrypt.txt file
	input.close();output.close(); // both files are closed
	cout<<endl;
	char * encrypt_data=new char[numofcharacters]; // new array is made of num of character in plainfile.txt
	input.open("encrypted3.txt");// encrypted file is opened to take input from
	output.open("decryted3.txt");// decrypted file is opened place the contents of the decrypted file
	i=0;
	while(!input.eof()) // while not end of file the loop will input data into array from encrypted file
	{
		encrypt_data[i]=input.get();;
		i++;
	}
	cout<<"Step 1 decrypted and placed in decrypted3.txt"<<endl;
	decrypt1(encrypt_data,i); // the data is send to function decrypt (for more info check doumentation)
	output.close();
	output.write(encrypt_data,i);// the decrypted data is written onto the decrypt.txt file
	output.open("decrypted2.txt");
	cout<<"Step 2 decrypted and placed in decrypted2.txt"<<endl;
	decrypt2(encrypt_data,i); // the data is send to function decrypt (for more info check doumentation)
	output.write(encrypt_data,i);// the decrypted data is written onto the decrypt.txt file
	output.close();
	output.open("decrypted1.txt");
	cout<<"Step 3 decrypted and placed in decrypted1.txt"<<endl;
	decrypt3(encrypt_data,i); // the data is send to function decrypt (for more info check doumentation)
	output.write(encrypt_data,i);// the decrypted data is written onto the decrypt.txt file
	input.close();output.close();// both files are closed
	cout<<endl;
	system("Pause");
	return 0;
}
