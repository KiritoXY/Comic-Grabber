#include <iostream>
#include <fstream>
using namespace std;

void encrypt(char *data, int count)
{
	__asm
	{
		mov esi,data;
		mov al,11111111b
		mov ecx,count
		l1:
			ror [esi],4
			xor [esi],al
			rol [esi],2
			inc esi
		loop l1
	}

}

void decrypt(char *data, int count)
{
	__asm
	{
		mov esi,data;
		mov al,11111111b
		mov ecx,count
		l1:
			ror [esi],2
			xor [esi],al
			rol [esi],4
			inc esi
		loop l1
	}

}

int main()
{
	int numofcharacters=0;char *data=NULL;char temp;
	ifstream input;ofstream output;
	input.open("plainfile.txt"); // the file to take data from
	output.open("encrypted.txt"); // the file to insert data in
	while(true) // this loop checks the number of character in the file
	{
		if(input.peek() == -1)
			break;
		temp=input.get();
		if(temp != '\n')
			numofcharacters++;
	}
	data = new char [numofcharacters]; // this allocates the space to data equal to num of character in input file
	input.close(); // file is closed
	input.open("plainfile.txt"); // file is opened again so that file pointer is on the top of file
	int i=0;
	cout<<"The Plain data read from file is"<<endl;
	while(!input.eof()) // inserting data from plainfile.txt in the array data
	{
		data[i]=input.get();
		cout<<data[i];
		i++;
	}
	cout<<endl;i--;
	encrypt(data,i); // the data is send to function encrypt (for more info check doumentation)
	cout<<endl<<"The Encrypted data wrote to the encrypted file"<<endl; // the encrypted data is written on console for the user to see
	for(int j=0;j<i;j++)
	{
		cout<<data[j];
	}
	output.write(data,i); // the encrypted data is written onto the encrypt.txt file
	input.close();output.close(); // both files are closed
	cout<<endl;
	char * encrypt_data=new char[numofcharacters]; // new array is made of num of character in plainfile.txt
	input.open("encrypted.txt");// encrypted file is opened to take input from
	output.open("decryted.txt");// decrypted file is opened place the contents of the decrypted file
	i=0;
	while(!input.eof()) // while not end of file the loop will input data into array from encrypted file
	{
		encrypt_data[i]=input.get();;
		i++;
	}
	decrypt(encrypt_data,i); // the data is send to function decrypt (for more info check doumentation)
	cout<<endl<<"The decryted data wrote in the decryted file is"<<endl;// the decrypted data is written on console for the user to see
	for(int j=0;j<i;j++)
	{
		cout<<encrypt_data[j];
	}
	output.write(encrypt_data,i);// the decrypted data is written onto the decrypt.txt file
	input.close();output.close();// both files are closed
	cout<<endl;
	system("Pause");
	return 0;
}
